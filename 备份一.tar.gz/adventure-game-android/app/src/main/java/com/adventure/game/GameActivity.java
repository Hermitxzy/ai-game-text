package com.adventure.game;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {
    
    static {
        System.loadLibrary("adventure-game");
    }
    
    private TextView outputText;
    private EditText inputText;
    private Button sendBtn;
    private ScrollView scrollView;
    private Button prevBtn;
    private Button nextBtn;
    private TextView commandText;
    private LinearLayout targetContainer;
    
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean apiAvailable = false;
    
    private String[] availableCommands = {};
    private int currentCommandIndex = -1;
    private String[] availableTargets = {};
    private int currentTargetIndex = -1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            setContentView(R.layout.activity_game);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        
        initViews();
        loadAvailableCommands();
        
        String modelPath = getIntent().getStringExtra("model_path");
        boolean gameInit = false;
        try {
            gameInit = initGame(modelPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
        final boolean finalGameInit = gameInit;
        
        loadAvailableCommands();
        
        onGameOutput("正在启动...\n检查 API 服务器...\n");
        
        new Thread(() -> {
            boolean connected = false;
            String msg = "";
            try {
                connected = ApiClient.isServerRunning();
            } catch (Exception e) {
                msg = "检查出错：" + e.getMessage() + "\n";
            }
            
            final boolean finalConnected = connected;
            final String finalMsg = msg;
            runOnUiThread(() -> {
                StringBuilder sb = new StringBuilder();
                if (finalConnected) {
                    sb.append("✓ API 服务器已连接\n");
                    sb.append("输入 'ask [问题]' 测试 AI 对话\n");
                } else {
                    sb.append("✗ API 服务器未响应\n");
                    sb.append("请在 Termux 中启动:\n");
                    sb.append("./server -m your-model.gguf --host 0.0.0.0 --port 8080\n");
                    if (!finalMsg.isEmpty()) sb.append(finalMsg);
                }
                
                if (finalGameInit) {
                    sb.append("\n游戏已加载！使用 ← → 按钮或输入命令\n");
                }
                
                onGameOutput(sb.toString());
            });
        }).start();
    }
    
    private void initViews() {
        outputText = findViewById(R.id.gameOutput);
        inputText = findViewById(R.id.gameInput);
        sendBtn = findViewById(R.id.sendBtn);
        scrollView = findViewById(R.id.scrollView);
        prevBtn = findViewById(R.id.prevBtn);
        nextBtn = findViewById(R.id.nextBtn);
        commandText = findViewById(R.id.commandText);
        targetContainer = findViewById(R.id.targetContainer);
        
        outputText.setMovementMethod(new ScrollingMovementMethod());
        sendBtn.setOnClickListener(this);
        prevBtn.setOnClickListener(this);
        nextBtn.setOnClickListener(this);
        
        inputText.setOnEditorActionListener((v, actionId, event) -> {
            sendMessage();
            return true;
        });
    }
    
    private void loadAvailableCommands() {
        String commands = getAvailableCommands();
        if (!TextUtils.isEmpty(commands)) {
            availableCommands = commands.split("\\|");
            currentCommandIndex = 0;
            updateCommandText();
        }
    }
    
    private void updateCommandText() {
        if (currentCommandIndex >= 0 && currentCommandIndex < availableCommands.length) {
            String cmd = availableCommands[currentCommandIndex];
            commandText.setText(cmd);
            
            // 对于不需要目标的命令，点击直接发送
            // 需要目标的命令：go, talk, gift, trade, interact, npc, remove_npc
            boolean needsTarget = cmd.equals("go") || cmd.equals("talk") || 
                                  cmd.equals("gift") || cmd.equals("trade") || 
                                  cmd.equals("interact") || cmd.equals("npc") || 
                                  cmd.equals("remove_npc");
            
            if (!needsTarget) {
                commandText.setOnClickListener(v -> {
                    inputText.setText(cmd);
                    sendMessage();
                });
                commandText.setClickable(true);
            } else {
                commandText.setOnClickListener(null);
                commandText.setClickable(false);
            }
            
            loadTargetsForCommand(cmd);
        } else {
            commandText.setText("命令选择");
            commandText.setOnClickListener(null);
            commandText.setClickable(false);
        }
    }
    
    private void loadTargetsForCommand(String command) {
        availableTargets = new String[0];
        currentTargetIndex = -1;
        targetContainer.removeAllViews();
        
        // 需要目标的命令：go, talk, gift, trade, interact, npc, remove_npc
        if (command.equals("go") || command.equals("talk") || 
            command.equals("gift") || command.equals("trade") || 
            command.equals("interact") || command.equals("npc") || 
            command.equals("remove_npc")) {
            String targets = getCommandTargets(command);
            if (!TextUtils.isEmpty(targets)) {
                availableTargets = targets.split("\\|");
                currentTargetIndex = 0;
                updateTargetButtons();
            }
        }
    }
    
    private void updateTargetButtons() {
        targetContainer.removeAllViews();
        
        if (availableTargets.length > 0) {
            for (int i = 0; i < availableTargets.length; i++) {
                final int index = i;
                Button targetBtn = new Button(this);
                targetBtn.setText(availableTargets[i]);
                targetBtn.setPadding(16, 8, 16, 8);
                targetBtn.setBackgroundColor(0xff4a4a6a);
                targetBtn.setTextColor(0xffffffff);
                
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
                params.setMargins(4, 0, 4, 0);
                targetBtn.setLayoutParams(params);
                
                targetBtn.setOnClickListener(v -> {
                    selectTarget(index);
                });
                
                targetContainer.addView(targetBtn);
            }
        }
    }
    
    private void selectTarget(int index) {
        if (index < 0 || index >= availableTargets.length) return;
        
        String cmd = availableCommands.length > 0 && currentCommandIndex >= 0 && currentCommandIndex < availableCommands.length 
            ? availableCommands[currentCommandIndex] : "";
        if (!cmd.isEmpty()) {
            String target = availableTargets[index];
            inputText.setText(cmd + " " + target);
        }
    }
    
    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.sendBtn) {
            sendMessage();
        } else if (id == R.id.prevBtn) {
            switchTarget(-1);
        } else if (id == R.id.nextBtn) {
            switchTarget(1);
        }
    }
    
    private void switchTarget(int direction) {
        if (availableCommands.length > 1) {
            currentCommandIndex += direction;
            if (currentCommandIndex < 0) currentCommandIndex = availableCommands.length - 1;
            if (currentCommandIndex >= availableCommands.length) currentCommandIndex = 0;
            updateCommandText();
        }
    }
    
    private void sendMessage() {
        String input = inputText.getText().toString().trim();
        if (TextUtils.isEmpty(input)) {
            return;
        }
        
        inputText.setText("");
        onGameOutput("> " + input);
        
        if (input.startsWith("ask ")) {
            handleAskCommand(input.substring(4));
        } else {
            String response = processInput(input);
            onGameOutput(response);
            loadAvailableCommands();
        }
    }
    
    private void handleAskCommand(String question) {
        onGameOutput("\n思考中...\n");
        
        new Thread(() -> {
            String response = ApiClient.generateResponse(question, 256);
            runOnUiThread(() -> {
                onGameOutput("AI: " + response + "\n\n");
            });
        }).start();
    }
    
    public void onGameOutput(final String text) {
        runOnUiThread(() -> {
            if (!TextUtils.isEmpty(text)) {
                outputText.append(text);
                if (!text.endsWith("\n")) {
                    outputText.append("\n");
                }
                scrollView.post(() -> {
                    scrollView.fullScroll(View.FOCUS_DOWN);
                });
            }
        });
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        cleanupGame();
    }
    
    // JNI 方法
    private native boolean initGame(String modelPath);
    private native String processInput(String input);
    private native void cleanupGame();
    private native boolean isGameRunning();
    private native String getCurrentScene();
    private native int getGold();
    private native String getAvailableCommands();
    private native String getCommandTargets(String command);
}
